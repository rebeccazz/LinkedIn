const CONFIG = {
  API_KEY: "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",
  API_URL: "https://api.groq.com/openai/v1/chat/completions",
  MODEL: "llama-3.1-8b-instant"
};